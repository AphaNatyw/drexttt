
function checkSentence() {
  const input = document.getElementById('sentenceInput').value.trim();
  const words = input.split(/\s+/);

  const feedback = document.getElementById('feedback');
  feedback.style.color = 'black';
  document.body.style.backgroundColor = '#f0f0f0';

  if (words.length < 2 || words.length > 4) {
    feedback.textContent = 'Please enter 2 to 4 words.';
    feedback.style.color = 'orange';
    return;
  }

  const isOriginal = Math.random() > 0.5;

  if (isOriginal) {
    feedback.textContent = 'Great! You got it right!';
    document.body.style.backgroundColor = '#c8f7c5';
    addRecentSentence(input);
  } else {
    feedback.textContent = 'Oops! This sentence has been said before!';
    document.body.style.backgroundColor = '#f7c5c5';
  }
}

function addRecentSentence(sentence) {
  const list = document.getElementById('recentSentences');
  const item = document.createElement('li');
  item.textContent = sentence;
  list.prepend(item);
  if (list.children.length > 5) {
    list.removeChild(list.lastChild);
  }
}
